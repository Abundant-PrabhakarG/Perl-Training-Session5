use strict;
use warnings;

use lib 'C:/Users/Local User/Documents/Perl-Training/Perl-Training-Session5-scripts/';
use Square;

my $a = Rectangle->new(5,10);

my $b = Square->new(4,4);

$a->getPerimeter();
$b->getPerimeter();