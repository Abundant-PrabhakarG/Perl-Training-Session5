use DBI;
use strict;

my $driver = "mysql"; 
my $database = "perlbase";
my $dsn = "DBI:$driver:database=$database";
my $userid = "root";
my $password = "dm2019";

my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;

my $name = "top";
my $location = "pune";
my $sth = $dbh->prepare("INSERT INTO info
                       (NAME, LOCATION )
                        values
                       (?,?)");
$sth->execute($name,$location) 
          or die $DBI::errstr;
$sth->finish();
