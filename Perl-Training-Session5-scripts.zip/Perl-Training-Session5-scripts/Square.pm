#file is Square.pm

package Square;

use strict;
use warnings;

use parent 'Rectangle';

sub getPerimeter{
  my $self = shift;
  print "Perimeter of square is ",4*($self->{'length'}),"\n";
}

1;