use strict;
use warnings;

#system "md directory";
#system "rd directory";
#system "ren file1.txt file2.txt";
system "del file2.txt";
