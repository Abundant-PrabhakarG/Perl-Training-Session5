#!C:/Perl64/bin/perl.exe

print "Content-Type: text/html\n\n";

print "<html>\n";
print "<head><title>Login form</title>\n";
print "</head>\n";
print "<body>\n";
print "<br><br><br><br><br><br><br><br>\n";
print "<center><h1> Perl Training Session</h1></center>\n";
print "<br><div align='center'><center>\n";

print "<form action='sendmail.pl' method='POST'>\n";
print "<table><tr><td>\n";
print "User name:</td><td> <input name='fullname'><br>\n";
print "</td></tr>\n";
print "<tr><td></td></tr>\n";
print "<tr><td>\n";
print "Password: </td><td><input name='password'><br>\n";
print "</td></tr></table>\n";
print "<input type='submit' value='Login'>\n";
print "</form>\n";
print "<\div>\n";
print "</body>\n";
print "</html>\n";