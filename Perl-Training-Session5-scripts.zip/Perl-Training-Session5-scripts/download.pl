use strict;
use warnings;

use LWP::Simple;

my $url = 'https://files.rcsb.org/view/6LYZ.pdb';
my $file = '6LYZ.pdb';

getstore($url, $file);
