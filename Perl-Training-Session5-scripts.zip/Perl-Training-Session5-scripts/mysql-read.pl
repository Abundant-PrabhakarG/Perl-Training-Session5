use DBI;
use strict;

my $driver = "mysql"; 
my $database = "perlbase";
my $dsn = "DBI:$driver:database=$database";
my $userid = "root";
my $password = "dm2019";

my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;

my $sth = $dbh->prepare("SELECT * from info");

$sth->execute() or die $DBI::errstr;


while (my @row = $sth->fetchrow_array()) {
   my ($first_name, $last_name ) = @row;
   print "Name = $first_name, Location = $last_name\n";
}

$sth->finish();